﻿namespace Proyecto_cliente
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Siguiente = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.numForm = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.num1 = new System.Windows.Forms.Label();
            this.num2 = new System.Windows.Forms.Label();
            this.num3 = new System.Windows.Forms.Label();
            this.num4 = new System.Windows.Forms.Label();
            this.num5 = new System.Windows.Forms.Label();
            this.num6 = new System.Windows.Forms.Label();
            this.num7 = new System.Windows.Forms.Label();
            this.num8 = new System.Windows.Forms.Label();
            this.num9 = new System.Windows.Forms.Label();
            this.num10 = new System.Windows.Forms.Label();
            this.num11 = new System.Windows.Forms.Label();
            this.num12 = new System.Windows.Forms.Label();
            this.num13 = new System.Windows.Forms.Label();
            this.num14 = new System.Windows.Forms.Label();
            this.num15 = new System.Windows.Forms.Label();
            this.num16 = new System.Windows.Forms.Label();
            this.num17 = new System.Windows.Forms.Label();
            this.num18 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Salir";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(799, 490);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Siguiente
            // 
            this.Siguiente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Siguiente.Location = new System.Drawing.Point(721, 496);
            this.Siguiente.Name = "Siguiente";
            this.Siguiente.Size = new System.Drawing.Size(75, 23);
            this.Siguiente.TabIndex = 4;
            this.Siguiente.Text = "Next";
            this.Siguiente.UseVisualStyleBackColor = false;
            this.Siguiente.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(361, 269);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 5;
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // numForm
            // 
            this.numForm.AutoSize = true;
            this.numForm.Location = new System.Drawing.Point(761, 17);
            this.numForm.Name = "numForm";
            this.numForm.Size = new System.Drawing.Size(35, 13);
            this.numForm.TabIndex = 6;
            this.numForm.Text = "label2";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(246, 349);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(333, 170);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(268, 371);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "3";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // num1
            // 
            this.num1.AutoSize = true;
            this.num1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num1.Location = new System.Drawing.Point(253, 362);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(47, 33);
            this.num1.TabIndex = 8;
            this.num1.Text = "32";
            this.num1.Click += new System.EventHandler(this.label2_Click);
            // 
            // num2
            // 
            this.num2.AutoSize = true;
            this.num2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num2.Location = new System.Drawing.Point(253, 417);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(47, 33);
            this.num2.TabIndex = 9;
            this.num2.Text = "32";
            // 
            // num3
            // 
            this.num3.AutoSize = true;
            this.num3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num3.Location = new System.Drawing.Point(253, 472);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(47, 33);
            this.num3.TabIndex = 10;
            this.num3.Text = "32";
            // 
            // num4
            // 
            this.num4.AutoSize = true;
            this.num4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num4.Location = new System.Drawing.Point(308, 362);
            this.num4.Name = "num4";
            this.num4.Size = new System.Drawing.Size(47, 33);
            this.num4.TabIndex = 11;
            this.num4.Text = "32";
            // 
            // num5
            // 
            this.num5.AutoSize = true;
            this.num5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num5.Location = new System.Drawing.Point(306, 417);
            this.num5.Name = "num5";
            this.num5.Size = new System.Drawing.Size(47, 33);
            this.num5.TabIndex = 12;
            this.num5.Text = "32";
            // 
            // num6
            // 
            this.num6.AutoSize = true;
            this.num6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num6.Location = new System.Drawing.Point(306, 472);
            this.num6.Name = "num6";
            this.num6.Size = new System.Drawing.Size(47, 33);
            this.num6.TabIndex = 13;
            this.num6.Text = "32";
            // 
            // num7
            // 
            this.num7.AutoSize = true;
            this.num7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num7.Location = new System.Drawing.Point(361, 362);
            this.num7.Name = "num7";
            this.num7.Size = new System.Drawing.Size(47, 33);
            this.num7.TabIndex = 14;
            this.num7.Text = "32";
            // 
            // num8
            // 
            this.num8.AutoSize = true;
            this.num8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num8.Location = new System.Drawing.Point(361, 417);
            this.num8.Name = "num8";
            this.num8.Size = new System.Drawing.Size(47, 33);
            this.num8.TabIndex = 15;
            this.num8.Text = "32";
            // 
            // num9
            // 
            this.num9.AutoSize = true;
            this.num9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num9.Location = new System.Drawing.Point(361, 472);
            this.num9.Name = "num9";
            this.num9.Size = new System.Drawing.Size(47, 33);
            this.num9.TabIndex = 16;
            this.num9.Text = "32";
            // 
            // num10
            // 
            this.num10.AutoSize = true;
            this.num10.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num10.Location = new System.Drawing.Point(414, 362);
            this.num10.Name = "num10";
            this.num10.Size = new System.Drawing.Size(47, 33);
            this.num10.TabIndex = 17;
            this.num10.Text = "32";
            // 
            // num11
            // 
            this.num11.AutoSize = true;
            this.num11.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num11.Location = new System.Drawing.Point(414, 417);
            this.num11.Name = "num11";
            this.num11.Size = new System.Drawing.Size(47, 33);
            this.num11.TabIndex = 18;
            this.num11.Text = "32";
            // 
            // num12
            // 
            this.num12.AutoSize = true;
            this.num12.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num12.Location = new System.Drawing.Point(414, 472);
            this.num12.Name = "num12";
            this.num12.Size = new System.Drawing.Size(47, 33);
            this.num12.TabIndex = 19;
            this.num12.Text = "32";
            // 
            // num13
            // 
            this.num13.AutoSize = true;
            this.num13.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num13.Location = new System.Drawing.Point(470, 362);
            this.num13.Name = "num13";
            this.num13.Size = new System.Drawing.Size(47, 33);
            this.num13.TabIndex = 20;
            this.num13.Text = "32";
            // 
            // num14
            // 
            this.num14.AutoSize = true;
            this.num14.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num14.Location = new System.Drawing.Point(470, 417);
            this.num14.Name = "num14";
            this.num14.Size = new System.Drawing.Size(47, 33);
            this.num14.TabIndex = 21;
            this.num14.Text = "32";
            // 
            // num15
            // 
            this.num15.AutoSize = true;
            this.num15.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num15.Location = new System.Drawing.Point(470, 472);
            this.num15.Name = "num15";
            this.num15.Size = new System.Drawing.Size(47, 33);
            this.num15.TabIndex = 22;
            this.num15.Text = "32";
            // 
            // num16
            // 
            this.num16.AutoSize = true;
            this.num16.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num16.Location = new System.Drawing.Point(527, 362);
            this.num16.Name = "num16";
            this.num16.Size = new System.Drawing.Size(47, 33);
            this.num16.TabIndex = 23;
            this.num16.Text = "32";
            // 
            // num17
            // 
            this.num17.AutoSize = true;
            this.num17.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num17.Location = new System.Drawing.Point(527, 417);
            this.num17.Name = "num17";
            this.num17.Size = new System.Drawing.Size(47, 33);
            this.num17.TabIndex = 24;
            this.num17.Text = "32";
            // 
            // num18
            // 
            this.num18.AutoSize = true;
            this.num18.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num18.Location = new System.Drawing.Point(527, 472);
            this.num18.Name = "num18";
            this.num18.Size = new System.Drawing.Size(47, 33);
            this.num18.TabIndex = 25;
            this.num18.Text = "32";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(828, 548);
            this.Controls.Add(this.num18);
            this.Controls.Add(this.num17);
            this.Controls.Add(this.num16);
            this.Controls.Add(this.num15);
            this.Controls.Add(this.num14);
            this.Controls.Add(this.num13);
            this.Controls.Add(this.num12);
            this.Controls.Add(this.num11);
            this.Controls.Add(this.num10);
            this.Controls.Add(this.num9);
            this.Controls.Add(this.num8);
            this.Controls.Add(this.num7);
            this.Controls.Add(this.num6);
            this.Controls.Add(this.num5);
            this.Controls.Add(this.num4);
            this.Controls.Add(this.num3);
            this.Controls.Add(this.num2);
            this.Controls.Add(this.num1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.numForm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Siguiente);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Siguiente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label numForm;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label num1;
        private System.Windows.Forms.Label num2;
        private System.Windows.Forms.Label num3;
        private System.Windows.Forms.Label num4;
        private System.Windows.Forms.Label num5;
        private System.Windows.Forms.Label num6;
        private System.Windows.Forms.Label num7;
        private System.Windows.Forms.Label num8;
        private System.Windows.Forms.Label num9;
        private System.Windows.Forms.Label num10;
        private System.Windows.Forms.Label num11;
        private System.Windows.Forms.Label num12;
        private System.Windows.Forms.Label num13;
        private System.Windows.Forms.Label num14;
        private System.Windows.Forms.Label num15;
        private System.Windows.Forms.Label num16;
        private System.Windows.Forms.Label num17;
        private System.Windows.Forms.Label num18;
    }
}